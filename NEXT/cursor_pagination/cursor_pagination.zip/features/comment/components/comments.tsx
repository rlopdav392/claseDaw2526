"use client";

import { useInfiniteQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { useInView } from "react-intersection-observer";
import { CommentItem } from "./comment-item";
import { getComments } from "../queries/get-comments";

type Props = {
  ticketId: string;
};

export function Comments({ ticketId }: Props) {
  const queryKey = ["comments", ticketId] as const;

  const { data, fetchNextPage, hasNextPage, isFetchingNextPage, isLoading } =
    useInfiniteQuery({
      queryKey,
      queryFn: ({ pageParam }) => getComments(ticketId, pageParam),
      initialPageParam: undefined as string | undefined,
      getNextPageParam: (lastPage) =>
        lastPage.metadata.hasNextPage ? lastPage.metadata.cursor : undefined,
    });

  const comments = data?.pages.flatMap((page) => page.list) ?? [];

  const { ref, inView } = useInView();

  useEffect(() => {
    if (inView && hasNextPage && !isFetchingNextPage) {
      fetchNextPage();
    }
  }, [fetchNextPage, hasNextPage, inView, isFetchingNextPage]);

  if (isLoading) {
    return <p className="text-sm text-gray-500">Cargando comentarios...</p>;
  }

  return (
    <>
      <div className="flex flex-col gap-y-2">
        {comments.map((comment) => (
          <CommentItem key={comment.id} comment={comment} />
        ))}

        {isFetchingNextPage && (
          <p className="text-center text-sm text-gray-500 py-4">
            Cargando más comentarios...
          </p>
        )}
      </div>

      <div ref={ref}>
        {!hasNextPage && comments.length > 0 && (
          <p className="text-right text-xs italic">No hay más comentarios.</p>
        )}
      </div>
    </>
  );
}
